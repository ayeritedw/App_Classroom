// User Management Canister
import Text "mo:base/Text";

type User = {
  id: Text;
  username: Text;
  email: Text;
  // Other user data
};

type UserManagement = actor {
  public func registerUser(username: Text, email: Text) : async User;
  public query func getUser(userId: Text) : async ?User;
};

public actor class UserManagementImpl() : UserManagement {
  private var users : [User] = [];
  
  public func registerUser(username: Text, email: Text) : async User {
    let newUser : User = {
      id = Text.fromNat(BigNat.toNat(now()));
      username = username;
      email = email;
    };
    users := users ++ [newUser];
    newUser;
  }

  public query func getUser(userId: Text) : async ?User {
    let user = Array.find(users, func(u) { u.id == userId });
    ?user;
  }
};
